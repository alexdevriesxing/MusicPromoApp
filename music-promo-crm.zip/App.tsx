
import React, { useState, useCallback, useEffect } from 'react';
import { Layout } from './components/Layout';
import { DatabaseView } from './components/DatabaseView';
import { ShortlistView } from './components/ShortlistView';
import { ReportingView } from './components/ReportingView';
import { CampaignView } from './components/CampaignView';
import { Contact, View, VerificationStatus } from './types';
import { ContactModal } from './components/ContactModal';
import { ImportModal } from './components/ImportModal';
import { verifyContactExistence } from './api';
import * as db from './db';

const App: React.FC = () => {
    const [contacts, setContacts] = useState<Contact[]>([]);
    const [countries, setCountries] = useState<string[]>([]);
    const [genres, setGenres] = useState<string[]>([]);
    const [currentView, setCurrentView] = useState<View>(View.Database);
    
    const [isContactModalOpen, setContactModalOpen] = useState(false);
    const [contactToEdit, setContactToEdit] = useState<Contact | null>(null);

    const [isImportModalOpen, setImportModalOpen] = useState(false);
    const [notification, setNotification] = useState<string | null>(null);

    const showNotification = (message: string) => {
        setNotification(message);
        setTimeout(() => setNotification(null), 4000);
    };

    useEffect(() => {
        const loadContacts = async () => {
            try {
                const storedContacts = await db.getAllContacts();
                if (storedContacts.length > 0) {
                    setContacts(storedContacts);
                } else {
                    showNotification("Setting up initial database...");
                    const response = await fetch('/seed-data.json');
                    if (!response.ok) {
                        throw new Error(`Failed to load seed data: ${response.statusText}`);
                    }
                    const seedContacts: Contact[] = await response.json();
                    await db.bulkAddContacts(seedContacts);
                    setContacts(seedContacts);
                    showNotification("Database setup complete!");
                }
            } catch (error) {
                console.error("Failed to load contacts from the database:", error);
                showNotification("Error: Could not initialize database.");
            }
        };
        loadContacts();
    }, []);

    useEffect(() => {
        if (contacts.length > 0) {
            const uniqueCountries = [...new Set(contacts.map(c => c.country))].sort((a, b) => a.localeCompare(b));
            const uniqueGenres = [...new Set(contacts.flatMap(c => c.genres))].sort((a, b) => a.localeCompare(b));
            setCountries(uniqueCountries);
            setGenres(uniqueGenres);
        }
    }, [contacts]);


    const handleAddContact = useCallback(async (contact: Omit<Contact, 'id'>) => {
        const newContact: Contact = { ...contact, id: Date.now().toString(), verificationStatus: 'unverified' };
        try {
            await db.addContact(newContact);
            setContacts(prev => [...prev, newContact]);
            showNotification('Contact added successfully!');
        } catch (error) {
            console.error("Failed to add contact:", error);
            showNotification('Error: Could not add contact.');
        }
    }, []);

    const handleUpdateContact = useCallback(async (updatedContact: Contact) => {
        try {
            await db.updateContact(updatedContact);
            setContacts(prev => prev.map(c => c.id === updatedContact.id ? updatedContact : c));
            showNotification('Contact updated successfully!');
        } catch (error) {
            console.error("Failed to update contact:", error);
            showNotification('Error: Could not update contact.');
        }
    }, []);

    const handleDeleteContact = useCallback(async (id: string) => {
        try {
            await db.deleteContact(id);
            setContacts(prev => prev.filter(c => c.id !== id));
            showNotification('Contact deleted.');
        } catch (error) {
            console.error("Failed to delete contact:", error);
            showNotification('Error: Could not delete contact.');
        }
    }, []);

    const handleVerifyContact = useCallback(async (id: string) => {
        const contactToVerify = contacts.find(c => c.id === id);
        if (!contactToVerify) return;

        const verifyingContact = { ...contactToVerify, verificationStatus: 'verifying' as VerificationStatus };
        setContacts(prev => prev.map(c => (c.id === id ? verifyingContact : c)));
        await db.updateContact(verifyingContact);

        try {
            const result = await verifyContactExistence(contactToVerify);
            const newStatus: VerificationStatus = result.exists ? 'verified' : 'not_found';
            
            const finalContact = { ...verifyingContact, verificationStatus: newStatus, verificationDetails: result.details };
            setContacts(prev => prev.map(c => (c.id === id ? finalContact : c)));
            await db.updateContact(finalContact);

            showNotification(`Verification for "${contactToVerify.name}" complete.`);
        } catch (error) {
            console.error(error);
            const errorContact = { ...verifyingContact, verificationStatus: 'error' as VerificationStatus, verificationDetails: 'Verification failed.' };
            setContacts(prev => prev.map(c => (c.id === id ? errorContact : c)));
            await db.updateContact(errorContact);
            showNotification(`Verification for "${contactToVerify.name}" failed.`);
        }
    }, [contacts]);

    const handleOpenAddModal = () => {
        setContactToEdit(null);
        setContactModalOpen(true);
    };

    const handleOpenEditModal = (contact: Contact) => {
        setContactToEdit(contact);
        setContactModalOpen(true);
    };

    const handleImportContacts = async (newContacts: Omit<Contact, 'id'>[]) => {
        const contactsWithIds = newContacts.map((c, index) => ({...c, id: `imported-${Date.now()}-${index}`, verificationStatus: 'unverified' as VerificationStatus}));
        try {
            await db.bulkAddContacts(contactsWithIds);
            setContacts(prev => [...prev, ...contactsWithIds]);
            showNotification(`Successfully imported ${newContacts.length} contacts.`);
        } catch (error) {
            console.error("Failed to import contacts:", error);
            showNotification('Error: Could not import contacts.');
        }
    };
    
    const handleBulkAdd = useCallback(async (newContacts: Omit<Contact, 'id'>[]) => {
        if (newContacts.length === 0) {
            showNotification('AI found no new contacts.');
            return;
        }
        const contactsWithIds = newContacts.map((c, index) => ({...c, id: `ai-${Date.now()}-${index}`, verificationStatus: 'unverified' as VerificationStatus}));
        try {
            await db.bulkAddContacts(contactsWithIds);
            setContacts(prev => [...prev, ...contactsWithIds]);
            showNotification(`Successfully found and added ${newContacts.length} new contacts!`);
        } catch (error) {
            console.error("Failed to add new contacts:", error);
            showNotification('Error: Could not save new contacts.');
        }
    }, []);

    return (
        <>
            <Layout 
                currentView={currentView} 
                setCurrentView={setCurrentView}
                onImportClick={() => setImportModalOpen(true)}
            >
                {currentView === View.Database && (
                    <DatabaseView 
                        contacts={contacts} 
                        onAdd={handleOpenAddModal} 
                        onEdit={handleOpenEditModal}
                        onDelete={handleDeleteContact}
                        onVerify={handleVerifyContact}
                        onBulkAdd={handleBulkAdd}
                    />
                )}
                {currentView === View.Shortlist && (
// Fix: Pass `genres` prop to `ShortlistView`.
                    <ShortlistView contacts={contacts} genres={genres} />
                )}
                {currentView === View.Reporting && (
                    <ReportingView contacts={contacts} />
                )}
                {currentView === View.Campaign && (
// Fix: Pass `genres` prop to `CampaignView`.
                    <CampaignView contacts={contacts} genres={genres} />
                )}
            </Layout>

            {isContactModalOpen && (
// Fix: Pass `countries` and `genres` props to `ContactModal`.
                <ContactModal 
                    isOpen={isContactModalOpen}
                    onClose={() => setContactModalOpen(false)}
                    onSaveAdd={handleAddContact}
                    onSaveEdit={handleUpdateContact}
                    contactToEdit={contactToEdit}
                    countries={countries}
                    genres={genres}
                />
            )}

            {isImportModalOpen && (
                 <ImportModal
                    isOpen={isImportModalOpen}
                    onClose={() => setImportModalOpen(false)}
                    onImport={handleImportContacts}
                />
            )}

            {notification && (
                 <div className="fixed bottom-5 right-5 bg-indigo-600 text-white py-2 px-4 rounded-lg shadow-lg animate-fade-in-out z-50">
                    {notification}
                 </div>
            )}
        </>
    );
};

export default App;
