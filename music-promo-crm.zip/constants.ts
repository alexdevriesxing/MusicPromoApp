import { ContactType } from './types';

export const CONTACT_TYPES: ContactType[] = Object.values(ContactType);
