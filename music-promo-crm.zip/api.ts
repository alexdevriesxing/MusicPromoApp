import { GoogleGenAI, Type } from "@google/genai";
import { Contact, ContactType } from './types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

interface VerificationResult {
    exists: boolean;
    details: string;
}

export const verifyContactExistence = async (contact: Contact): Promise<VerificationResult> => {
    const prompt = `Is there a real, currently operating entity of type "${contact.type}" called "${contact.name}" in ${contact.country}? 
    
    If it exists, confirm and provide its official website if you can find it.
    If you cannot find it or are unsure, state that.
    
    Respond in JSON format.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        exists: {
                            type: Type.BOOLEAN,
                            description: 'Whether the entity is real and operational.'
                        },
                        details: {
                            type: Type.STRING,
                            description: 'A brief explanation of the findings, including the official website if found.'
                        }
                    },
                    required: ["exists", "details"],
                },
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);
        
        return result as VerificationResult;

    } catch (error) {
        console.error("Error verifying contact with Gemini API:", error);
        return {
            exists: false,
            details: "An error occurred during verification. Please try again later."
        };
    }
};

export const findNewContacts = async (country: string, existingContactNames: string[]): Promise<Omit<Contact, 'id'>[]> => {
    const prompt = `
    Find 5 real, currently operating radio stations in ${country}.
    These should be good targets for independent music promotion. Avoid major mainstream networks if possible.
    Do NOT include any of the following names in your response: ${existingContactNames.join(', ')}.

    For each one, provide:
    - name: The official name of the station.
    - email: A valid public contact or music submission email address.
    - website: The official website URL.
    - genres: An array of 2-3 primary music genres they play.

    Respond ONLY in JSON format, as an array of objects.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING },
                            email: { type: Type.STRING },
                            website: { type: Type.STRING },
                            genres: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING }
                            },
                        },
                        required: ["name", "email", "website", "genres"]
                    }
                },
            },
        });

        const jsonString = response.text.trim();
        const results = JSON.parse(jsonString);

        // Map the results to our Contact type structure
        return results.map((item: any) => ({
            ...item,
            country: country,
            type: ContactType.RadioStation, // Hardcoded for now
            verificationStatus: 'unverified',
        }));

    } catch (error) {
        console.error("Error finding new contacts with Gemini API:", error);
        throw new Error("AI failed to find new contacts. It might be busy, please try again in a moment.");
    }
};

interface CampaignEmail {
    subject: string;
    body: string;
}

interface CampaignDetails {
    artistName: string;
    songTitle: string;
    songGenre: string;
    streamLink: string;
    downloadLink: string;
    extraInfo: string;
    socialLinks: string;
}

export const generateCampaignEmail = async (details: CampaignDetails): Promise<CampaignEmail> => {
    const { artistName, songTitle, songGenre, streamLink, downloadLink, extraInfo, socialLinks } = details;
    
    const prompt = `
You are a friendly and passionate music promoter crafting a polite email to send to radio stations, DJs, and music reviewers.
Your tone should be professional but also warm, respectful, and not pushy. You understand they are busy, so the email should be concise.
Your goal is to build a positive connection and gently encourage them to listen to a new single.

Here is the information about the track:
- Artist: ${artistName}
- Song Title: ${songTitle}
- Genre: ${songGenre}
- Streaming Link (Spotify/Youtube): ${streamLink}
- Download Link (WeTransfer): ${downloadLink}
- Social Media: ${socialLinks}
- Additional Information: ${extraInfo}

Based on this, generate a subject line and an email body.

The email body should:
1. Start with a polite and professional greeting (e.g., "Hi [Name/Team], I hope you're having a great week.").
2. Briefly introduce the artist and their new single, mentioning the genre.
3. Highlight what makes the song special or interesting (use the 'Additional Information' if relevant).
4. Provide the streaming and download links clearly.
5. In a friendly and humble tone, ask if they might be willing to give the song a listen for consideration.
6. Include the social media links for them to connect with the artist if they're interested. If multiple links are provided, format them as a clean list.
7. End with a professional and appreciative closing, thanking them for their time and consideration (e.g., "Thanks so much for your time,").

Respond ONLY in JSON format.
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        subject: {
                            type: Type.STRING,
                            description: 'A catchy and professional email subject line.'
                        },
                        body: {
                            type: Type.STRING,
                            description: 'The full body of the promotional email, formatted with line breaks.'
                        }
                    },
                    required: ["subject", "body"],
                },
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);
        
        return result as CampaignEmail;

    } catch (error) {
        console.error("Error generating campaign email with Gemini API:", error);
        throw new Error("Failed to generate AI email. Please check your inputs and try again.");
    }
};