import React, { useState, useMemo, useCallback } from 'react';
import { Contact, SortConfig, SocialPlatform, ContactPerson } from '../types';
import { 
    EditIcon, TrashIcon, SortUpIcon, SortDownIcon, LinkIcon, VerifyIcon, LoadingSpinnerIcon, 
    VerifiedIcon, NotFoundIcon, ErrorIcon, UnverifiedIcon, FacebookIcon, TwitterIcon, 
    InstagramIcon, YoutubeIcon, SpotifyIcon, SoundcloudIcon, BandcampIcon, TiktokIcon, BellIcon, BellSlashIcon
} from './Icons';

interface DataTableProps {
    contacts: Contact[];
    onEdit: (contact: Contact) => void;
    onDelete: (id: string) => void;
    onVerify: (id: string) => void;
}

const SortableHeader: React.FC<{
    label: string;
    sortKey: keyof Contact;
    sortConfig: SortConfig;
    requestSort: (key: keyof Contact) => void;
}> = ({ label, sortKey, sortConfig, requestSort }) => {
    const isSorted = sortConfig?.key === sortKey;
    const direction = isSorted ? sortConfig.direction : undefined;

    return (
        <th
            className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer select-none group"
            onClick={() => requestSort(sortKey)}
        >
            <div className="flex items-center">
                {label}
                <span className="ml-2">
                    {isSorted ? (
                        direction === 'ascending' ? <SortUpIcon className="h-4 w-4 text-indigo-400" /> : <SortDownIcon className="h-4 w-4 text-indigo-400" />
                    ) : (
                       <SortUpIcon className="h-4 w-4 text-gray-600 group-hover:text-gray-400 transition" />
                    )}
                </span>
            </div>
        </th>
    );
};

const SocialIcon: React.FC<{ platform: SocialPlatform; url?: string }> = ({ platform, url }) => {
    const icons: Record<SocialPlatform, React.ReactNode> = {
        facebook: <FacebookIcon className="h-5 w-5" />,
        twitter: <TwitterIcon className="h-5 w-5" />,
        instagram: <InstagramIcon className="h-5 w-5" />,
        youtube: <YoutubeIcon className="h-5 w-5" />,
        spotify: <SpotifyIcon className="h-5 w-5" />,
        soundcloud: <SoundcloudIcon className="h-5 w-5" />,
        bandcamp: <BandcampIcon className="h-5 w-5" />,
        tiktok: <TiktokIcon className="h-5 w-5" />,
    };

    const icon = icons[platform];
    const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);

    if (url) {
        return (
            <a
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                title={platformName}
                className="text-gray-400 hover:text-indigo-400 transition"
                aria-label={`Visit ${platformName} profile`}
            >
                {icon}
            </a>
        );
    } else {
        return (
            <span
                title={platformName}
                className="text-gray-500 cursor-not-allowed"
            >
                {icon}
            </span>
        );
    }
};

export const DataTable: React.FC<DataTableProps> = ({ contacts, onEdit, onDelete, onVerify }) => {
    const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'name', direction: 'ascending' });

    const socialPlatforms: SocialPlatform[] = ['facebook', 'twitter', 'instagram', 'youtube', 'spotify', 'soundcloud', 'bandcamp', 'tiktok'];

    const sortedContacts = useMemo(() => {
        let sortableItems = [...contacts];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                const aValue = a[sortConfig.key];
                const bValue = b[sortConfig.key];
                
                if (aValue === undefined || aValue === null) return 1;
                if (bValue === undefined || bValue === null) return -1;

                if (typeof aValue === 'string' && typeof bValue === 'string') {
                    const comparison = aValue.localeCompare(bValue, undefined, { sensitivity: 'base' });
                    return sortConfig.direction === 'ascending' ? comparison : -comparison;
                }

                if (aValue < bValue) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [contacts, sortConfig]);

    const requestSort = useCallback((key: keyof Contact) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    }, [sortConfig]);

    const getStatusIcon = (contact: Contact) => {
        switch (contact.verificationStatus) {
            case 'verified':
                return <VerifiedIcon className="h-5 w-5 text-green-500" />;
            case 'not_found':
                return <NotFoundIcon className="h-5 w-5 text-red-500" />;
            case 'verifying':
                return <LoadingSpinnerIcon className="h-5 w-5 text-indigo-400" />;
            case 'error':
                return <ErrorIcon className="h-5 w-5 text-yellow-500" />;
            case 'unverified':
            default:
                return <UnverifiedIcon className="h-5 w-5 text-gray-500" />;
        }
    }

    const handleToggleDNC = (contact: Contact) => {
        onEdit({ ...contact, doNotContact: !contact.doNotContact });
    };

    return (
        <div className="overflow-x-auto bg-gray-800 rounded-lg shadow-lg border border-gray-700">
            <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-gray-800">
                    <tr>
                        <SortableHeader label="Name" sortKey="name" sortConfig={sortConfig} requestSort={requestSort} />
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                        <SortableHeader label="Type" sortKey="type" sortConfig={sortConfig} requestSort={requestSort} />
                        <SortableHeader label="Country" sortKey="country" sortConfig={sortConfig} requestSort={requestSort} />
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Genres</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Contact</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Contact Persons</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Socials</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody className="bg-gray-800 divide-y divide-gray-700">
                    {sortedContacts.map((contact) => (
                        <tr key={contact.id} className={`hover:bg-gray-700/50 transition-colors ${contact.doNotContact ? 'opacity-50' : ''}`}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-100">{contact.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                <div className="relative group flex items-center justify-center" title={contact.verificationDetails || contact.verificationStatus}>
                                    {getStatusIcon(contact)}
                                </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{contact.type}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{contact.country}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                <div className="flex flex-wrap gap-1">
                                    {contact.genres.map(genre => (
                                        <span key={genre} className="px-2 py-1 text-xs bg-indigo-500/20 text-indigo-300 rounded-full">{genre}</span>
                                    ))}
                                </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                <div className="flex items-center">{contact.email}</div>
                                {contact.website && (
                                    <a href={contact.website} target="_blank" rel="noopener noreferrer" className="flex items-center text-indigo-400 hover:text-indigo-300 text-xs mt-1">
                                        <LinkIcon className="h-3 w-3 mr-1" />
                                        {contact.website}
                                    </a>
                                )}
                            </td>
                            <td className="px-6 py-4 align-top text-sm text-gray-300">
                                {(contact.contactPersons || []).length > 0 ? (
                                    <ul className="space-y-2">
                                        {contact.contactPersons?.map((person, index) => (
                                            <li key={index}>
                                                <p className="font-medium text-gray-100">{person.name}</p>
                                                <p className="text-xs text-gray-400">{person.position}</p>
                                                <a href={`mailto:${person.email}`} className="text-xs text-indigo-400 hover:underline">{person.email}</a>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <span className="text-gray-500">N/A</span>
                                )}
                            </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                <div className="flex items-center gap-3">
                                    {socialPlatforms.map(platform => (
                                        <SocialIcon key={platform} platform={platform} url={contact.socials?.[platform]} />
                                    ))}
                                </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button
                                    onClick={() => handleToggleDNC(contact)}
                                    className="text-gray-400 hover:text-white mr-4 transition"
                                    title={contact.doNotContact ? 'Allow contact (currently excluded)' : 'Do not contact (exclude from shortlists)'}
                                >
                                    {contact.doNotContact ? <BellSlashIcon className="h-5 w-5 text-yellow-500" /> : <BellIcon className="h-5 w-5" />}
                                </button>
                                <button
                                    onClick={() => onVerify(contact.id)}
                                    disabled={contact.verificationStatus === 'verifying' || contact.verificationStatus === 'verified'}
                                    className="text-indigo-400 hover:text-indigo-300 mr-4 transition disabled:text-gray-600 disabled:cursor-not-allowed"
                                    title="Verify with AI"
                                >
                                    <VerifyIcon className="h-5 w-5"/>
                                </button>
                                <button onClick={() => onEdit(contact)} className="text-yellow-400 hover:text-yellow-300 mr-4 transition"><EditIcon className="h-5 w-5"/></button>
                                <button onClick={() => onDelete(contact.id)} className="text-red-500 hover:text-red-400 transition"><TrashIcon className="h-5 w-5"/></button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};