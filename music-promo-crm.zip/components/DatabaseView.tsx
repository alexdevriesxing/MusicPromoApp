import React, { useState, useMemo } from 'react';
import { Contact } from '../types';
import { DataTable } from './DataTable';
import { PlusIcon, SearchIcon, SparklesIcon } from './Icons';
import { findNewContacts } from '../api';

interface DatabaseViewProps {
    contacts: Contact[];
    onAdd: () => void;
    onEdit: (contact: Contact) => void;
    onDelete: (id: string) => void;
    onVerify: (id: string) => void;
    onBulkAdd: (contacts: Omit<Contact, 'id'>[]) => void;
}

export const DatabaseView: React.FC<DatabaseViewProps> = ({ contacts, onAdd, onEdit, onDelete, onVerify, onBulkAdd }) => {
    const [countryFilter, setCountryFilter] = useState<string>('All');
    const [searchTerm, setSearchTerm] = useState('');
    const [isFinding, setIsFinding] = useState(false);

    const availableCountries = useMemo(() => {
        const countryCounts: Record<string, number> = contacts.reduce((acc, contact) => {
            acc[contact.country] = (acc[contact.country] || 0) + 1;
            return acc;
        }, {});

        const sortedCountries = Object.keys(countryCounts).sort((a, b) => a.localeCompare(b));
        
        return [{ name: 'All', count: contacts.length }, ...sortedCountries.map(name => ({ name, count: countryCounts[name] }))];
    }, [contacts]);

    const filteredContacts = useMemo(() => {
        let filtered = contacts;

        if (countryFilter !== 'All') {
            filtered = filtered.filter(c => c.country === countryFilter);
        }

        if (searchTerm) {
            const lowercasedTerm = searchTerm.toLowerCase();
            filtered = filtered.filter(contact =>
                Object.entries(contact).some(([key, value]) => {
                    if (key === 'genres' && Array.isArray(value)) {
                        return value.some(g => g.toLowerCase().includes(lowercasedTerm));
                    }
                     if (typeof value === 'string' || typeof value === 'number') {
                        return String(value).toLowerCase().includes(lowercasedTerm);
                    }
                    return false;
                })
            );
        }
        return filtered;
    }, [contacts, countryFilter, searchTerm]);

    const handleFindNew = async () => {
        if (countryFilter === 'All') return;
        setIsFinding(true);
        try {
            const existingNames = contacts.filter(c => c.country === countryFilter).map(c => c.name);
            const newContacts = await findNewContacts(countryFilter, existingNames);
            onBulkAdd(newContacts);
        } catch (error: any) {
            console.error(error);
            alert(error.message || "Failed to find new contacts.");
        } finally {
            setIsFinding(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center gap-4 flex-wrap">
                 <h2 className="text-2xl font-bold text-white">
                    Contact Database
                    <span className="ml-3 text-lg font-medium text-gray-400">({filteredContacts.length} shown)</span>
                </h2>
                <div className="flex items-center gap-2">
                    <button
                        onClick={handleFindNew}
                        disabled={isFinding || countryFilter === 'All'}
                        className="flex-shrink-0 flex items-center justify-center px-4 py-2 bg-purple-600 text-white font-semibold rounded-md hover:bg-purple-700 transition-colors duration-200 shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500 disabled:bg-purple-800 disabled:text-gray-400 disabled:cursor-not-allowed"
                        title={countryFilter === 'All' ? 'Select a country to enhance' : `Find new contacts in ${countryFilter}`}
                    >
                        <SparklesIcon className={`h-5 w-5 mr-2 ${isFinding ? 'animate-pulse' : ''}`} />
                        {isFinding ? 'Searching...' : 'Enhance with AI'}
                    </button>
                     <button
                        onClick={onAdd}
                        className="flex-shrink-0 flex items-center justify-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors duration-200 shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500"
                    >
                        <PlusIcon className="h-5 w-5 mr-2" />
                        Add Contact
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-800 rounded-lg border border-gray-700">
                <div className="md:col-span-1">
                    <label htmlFor="search-input" className="sr-only">Search</label>
                    <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                            <SearchIcon className="h-5 w-5 text-gray-500" />
                        </span>
                        <input
                            id="search-input"
                            type="text"
                            placeholder="Search all fields..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                        />
                    </div>
                </div>
                <div className="md:col-span-1">
                    <label htmlFor="country-filter" className="sr-only">Filter by Country</label>
                    <select
                        id="country-filter"
                        value={countryFilter}
                        onChange={e => setCountryFilter(e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                    >
                        {availableCountries.map(({ name, count }) => (
                            <option key={name} value={name}>
                                {name === 'All' ? 'All Countries' : name} ({count})
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            <DataTable contacts={filteredContacts} onEdit={onEdit} onDelete={onDelete} onVerify={onVerify} />
        </div>
    );
};
