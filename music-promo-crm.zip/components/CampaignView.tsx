
import React, { useState, useMemo } from 'react';
import { Contact } from '../types';
import { CampaignIcon, LoadingSpinnerIcon, CopyIcon } from './Icons';
import { generateCampaignEmail } from '../api';
// Fix: Removed non-existent GENRES import. Genres are now passed as a prop.

interface CampaignViewProps {
    contacts: Contact[];
    // Fix: Added genres to props to receive the list of available genres.
    genres: string[];
}

const initialFormState = {
    artistName: '',
    songTitle: '',
    songGenre: '',
    streamLink: '',
    downloadLink: '',
    extraInfo: '',
    socialLinks: ''
};

export const CampaignView: React.FC<CampaignViewProps> = ({ contacts, genres }) => {
    const [formData, setFormData] = useState(initialFormState);
    const [generatedEmail, setGeneratedEmail] = useState<{ subject: string; body: string } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [copySuccess, setCopySuccess] = useState('');

    const allEmails = useMemo(() => contacts.map(c => c.email).join(', '), [contacts]);

    const handleCopy = () => {
        if (allEmails) {
            navigator.clipboard.writeText(allEmails).then(() => {
                setCopySuccess('Copied!');
                setTimeout(() => setCopySuccess(''), 2000);
            }, () => {
                setCopySuccess('Failed to copy.');
                setTimeout(() => setCopySuccess(''), 2000);
            });
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleGenerateClick = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setIsLoading(true);
        setGeneratedEmail(null);
        try {
            const result = await generateCampaignEmail(formData);
            setGeneratedEmail(result);
        } catch (err: any) {
            setError(err.message || 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const isFormValid = useMemo(() => {
        return formData.artistName && formData.songTitle && formData.streamLink && formData.downloadLink;
    }, [formData]);

    return (
        <div className="space-y-6">
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <h2 className="text-2xl font-bold mb-2 text-white flex items-center">
                    <CampaignIcon className="h-6 w-6 mr-3 text-indigo-400"/>
                    AI-Powered Email Campaign Builder
                </h2>
                <p className="text-gray-400 mb-6">Fill in the details below, and let AI craft the perfect promotional email for your new release.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                {/* --- Form Column --- */}
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                     <h3 className="text-xl font-semibold text-gray-200 mb-4">Campaign Details</h3>
                    <form onSubmit={handleGenerateClick} className="space-y-4">
                        <InputField label="Name of the Artist" name="artistName" value={formData.artistName} onChange={handleChange} required />
                        <InputField label="Name of the Song" name="songTitle" value={formData.songTitle} onChange={handleChange} required />
                        
                        <div>
                            <label htmlFor="songGenre" className="block text-sm font-medium text-gray-300 mb-1">Song Genre</label>
                            <select
                                id="songGenre"
                                name="songGenre"
                                value={formData.songGenre}
                                onChange={handleChange}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm"
                            >
                                <option value="" disabled>Select a genre</option>
                                {/* Fix: Use `genres` prop instead of non-existent `GENRES` constant. */}
                                {genres.map(genre => (
                                    <option key={genre} value={genre}>{genre}</option>
                                ))}
                            </select>
                        </div>

                        <InputField label="Streaming Link (YouTube, Spotify, etc.)" name="streamLink" type="url" value={formData.streamLink} onChange={handleChange} required />
                        <InputField label="Download Link (WeTransfer, Dropbox, etc.)" name="downloadLink" type="url" value={formData.downloadLink} onChange={handleChange} required />
                        <InputField label="Social Media Links" name="socialLinks" value={formData.socialLinks} onChange={handleChange} placeholder="e.g., Instagram, Twitter (comma-separated)" />
                        
                        <div>
                            <label htmlFor="extraInfo" className="block text-sm font-medium text-gray-300 mb-1">Additional Information</label>
                            <textarea
                                id="extraInfo"
                                name="extraInfo"
                                value={formData.extraInfo}
                                onChange={handleChange}
                                rows={4}
                                placeholder="Any key selling points, press quotes, or interesting facts about the song."
                                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm"
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={!isFormValid || isLoading}
                            className="w-full flex items-center justify-center px-4 py-3 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors duration-200 shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 disabled:bg-indigo-800 disabled:cursor-not-allowed"
                        >
                            {isLoading ? <><LoadingSpinnerIcon className="h-5 w-5 mr-2" /> Generating...</> : 'Generate Email with AI'}
                        </button>
                    </form>
                </div>

                {/* --- Composer Column --- */}
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 sticky top-6">
                     <h3 className="text-xl font-semibold text-gray-200 mb-4">Generated Email Composer</h3>
                    {isLoading && (
                        <div className="flex flex-col items-center justify-center h-96 text-gray-400">
                            <LoadingSpinnerIcon className="h-8 w-8 mb-4" />
                            <p>Generating your email...</p>
                        </div>
                    )}
                    {error && !isLoading && (
                        <div className="flex flex-col items-center justify-center h-96 text-red-400">
                             <p className="font-semibold">Generation Failed</p>
                             <p className="text-sm text-center mt-2">{error}</p>
                        </div>
                    )}
                    {!isLoading && !generatedEmail && !error && (
                        <div className="flex flex-col items-center justify-center h-96 text-gray-500">
                            <p>Your generated email will appear here.</p>
                        </div>
                    )}
                    {generatedEmail && !isLoading && (
                        <div className="space-y-4">
                            <div>
                                <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-1">Subject</label>
                                <input
                                    id="subject"
                                    type="text"
                                    value={generatedEmail.subject}
                                    onChange={(e) => setGeneratedEmail(g => g ? { ...g, subject: e.target.value } : null)}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                                />
                            </div>
                            <div>
                                <label htmlFor="body" className="block text-sm font-medium text-gray-300 mb-1">Body</label>
                                <textarea
                                    id="body"
                                    value={generatedEmail.body}
                                    onChange={(e) => setGeneratedEmail(g => g ? { ...g, body: e.target.value } : null)}
                                    rows={12}
                                    className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm leading-relaxed"
                                />
                            </div>
                             <div>
                                <div className="flex justify-between items-center mb-1">
                                    <label className="block text-sm font-medium text-gray-300">Recipients ({contacts.length})</label>
                                    <button
                                        onClick={handleCopy}
                                        className="flex items-center px-3 py-1 bg-gray-600 text-white text-xs font-semibold rounded-md hover:bg-gray-500 transition"
                                    >
                                        {copySuccess ? copySuccess : <><CopyIcon className="h-3 w-3 mr-1.5"/> Copy All</>}
                                    </button>
                                </div>
                                <textarea
                                    readOnly
                                    value={allEmails}
                                    rows={2}
                                    className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 text-gray-400 font-mono text-xs resize-none focus:outline-none"
                                />
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

// Helper component for form inputs
const InputField: React.FC<{
    label: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    type?: string;
    required?: boolean;
    placeholder?: string;
}> = ({ label, name, value, onChange, type = 'text', required = false, placeholder = '' }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300 mb-1">
            {label} {required && <span className="text-red-400">*</span>}
        </label>
        <input
            id={name}
            name={name}
            type={type}
            value={value}
            onChange={onChange}
            required={required}
            placeholder={placeholder}
            className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm"
        />
    </div>
);
