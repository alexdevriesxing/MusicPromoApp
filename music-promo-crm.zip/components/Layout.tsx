
import React from 'react';
import { Sidebar } from './Sidebar';
import { View } from '../types';
import { MusicNoteIcon } from './Icons';

interface LayoutProps {
    children: React.ReactNode;
    currentView: View;
    setCurrentView: (view: View) => void;
    onImportClick: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentView, setCurrentView, onImportClick }) => {
    return (
        <div className="flex h-screen bg-gray-900 text-gray-100 font-sans">
            <Sidebar 
                currentView={currentView} 
                setCurrentView={setCurrentView} 
                onImportClick={onImportClick}
            />
            <main className="flex-1 flex flex-col overflow-hidden">
                <header className="bg-gray-800 shadow-md p-4 flex items-center border-b border-gray-700">
                    <MusicNoteIcon className="h-6 w-6 mr-3 text-indigo-400" />
                    <h1 className="text-xl font-bold tracking-wider text-gray-200">Music Promo CRM</h1>
                </header>
                <div className="flex-1 p-6 overflow-y-auto bg-gray-900">
                    {children}
                </div>
            </main>
        </div>
    );
};
